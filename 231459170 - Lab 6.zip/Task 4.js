var text1 = "Lorem Ipsum is simply dummy text of the printing and typesetting industry.";
document.write(text1.fontsize(4.5));

var text2 = " Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.";
document.write(text2.bold().fontsize(5.5));

var text3 = " It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially"; 
document.write(text3.fontsize(4.5));

var text4 = " UNCHANGED.";
document.write(text4.bold().fontsize(5));

var text5 = "It was popularised in the";
document.write(text5.fontsize(4.5));

var text6 = "1960";
document.write(text6.bold().fontsize(4.5));

var text7 = "s";
document.write(text7.small().bold())

var text8 = " with the release of";
document.write(text8.fontsize(4.5));

var text9 = " LETRASET";
document.write(text9.bold().fontsize(5));

var text10 = " sheets containing Lorem Ipsum passages, ";
document.write(text10.fontsize(4.5))

var text11 = "and more recently with desktop";
document.write(text11.fontsize(4.5).strike());

var text12 = " publishing software like Aldus";
document.write(text12.fontsize(4.5))

var text13 = " PageMaker";
document.write(text13.link('https://www.lipsum.com/').fontsize(4.5));

var text14 = " including versions of";
document.write(text14.fontsize(4.5));

var text15 = " Lorem Ipsum.";
document.write(text15.big().italics().fontsize(5));
 