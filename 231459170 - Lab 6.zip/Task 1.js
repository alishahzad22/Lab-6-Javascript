function sum()
{
  var num1, num2, sum;
  num1=parseInt(document.getElementById("a").value);
  num2=parseInt(document.getElementById("b").value);
  sum=num1+num2;
  document.getElementById("n1").value = sum;
}

function Product()
{
  var num1, num2, mul;
  num1=parseInt(document.getElementById("a").value);
  num2=parseInt(document.getElementById("b").value);
  mul=num1*num2;
  document.getElementById("n2").value = mul;
}

function Divison()
{
  var num1, num2, div;
  num1=parseInt(document.getElementById("a").value);
  num2=parseInt(document.getElementById("b").value);
  div=num1/num2;
  document.getElementById("n3").value = div;
}

function Subtraction()
{
  var num1, num2, mul;
  num1=parseInt(document.getElementById("a").value);
  num2=parseInt(document.getElementById("b").value);
  sub=num1-num2;
  document.getElementById("n4").value = sub;
}