var show=document.getElementById("show");show.addEventListener("click",function(){document.getElementById("box2").style.display="block";});
var ok=document.getElementById("ok").addEventListener("click",function(){document.getElementById("box2").style.display="none";});
